import { system , world } from "@minecraft/server";  
const ver = "1.2.0";  
const initTime = 105;  
const v = world.getDimension("overworld"); 
let tickDelay = 0;

system.runTimeout(() => {
    try {
        world.sendMessage(`⨀ | §6Mobs+ v${ver} Loaded`);
        v.runCommandAsync('function moremobs/init');
    } catch (e) { }
    
}, initTime);

system.runInterval(() => {
    try {
        v.runCommandAsync("function moremobs/_main");
    } 
    catch (e) {console.warn("Error: " + e);}
    
}, tickDelay);
