import * as mc from "@minecraft/server";

// Constants
const VERSION = "1.6.1";
const INIT_TIME = 110;
const TICK_DELAY = 0;

// World Dimension
const overworld = mc.world.getDimension("overworld");

// Tick Counters
let currentTick = 0;

// Initialization
mc.system.runTimeout(() => {
    try {
        mc.world.sendMessage(`⨀ | §6Auto-Miner+ v${VERSION} Loaded`);
        overworld.runCommandAsync('function auto_miner/init');
    } catch (error) {
        console.warn("Initialization Error:", error);
    }
}, INIT_TIME);

// Main Loop
mc.system.runInterval(() => {
    try {
        if (currentTick > INIT_TIME) {
            overworld.runCommandAsync("function auto_miner/_main");
            handleAutoMiner();
            const players = mc.world.getAllPlayers();
            players.forEach(getOwner);
        }
        currentTick++;
    } catch (error) {
        console.warn("Main Loop Error:", error);
    }
}, TICK_DELAY);

// Handle Auto Miner
function handleAutoMiner() {
    const autoMinerEntities = overworld.getEntities({ families: ['lab.auto_miner'] });
    for (const entity of autoMinerEntities) {
        if (entity.hasTag('has.hopper')) {
            transportItems(entity);
        }
    }
}

// Transport Items
function transportItems(entity) {
    const location = entity.location;
    const tags = entity.getTags();
    //console.warn("Entity Tags:", JSON.stringify(tags));

    const ownerTag = tags.find(tag => tag.startsWith("owner:"))?.substring("owner:".length);
    if (!ownerTag) {
        console.warn("Owner tag not found for entity:", entity);
        return;
    }

    const nearbyItems = overworld.getEntities({
        type: "minecraft:item",
        maxDistance: 5,
        location: location
    });

    const pumpLocations = getNearestPump(ownerTag);
    if (pumpLocations.length > 0) {
        const dropLocation = pumpLocations[0];
        for (const item of nearbyItems) {
            item.teleport(dropLocation);
        }
    } else {
        //console.warn("No pump location found for owner:", ownerTag);
    }
}

// Entity Spawn Event
mc.world.afterEvents.entitySpawn.subscribe(event => {
    const { entity } = event;
    if ((entity.typeId === 'lab:pump' || entity.typeId.includes('lab:auto_miner')) && !entity.hasTag('owned')) {
        const location = entity.location;
        const nearestPlayer = getNearestPlayer(5, location);
        if (nearestPlayer) {
            //console.warn(`${nearestPlayer} has claimed ${entity.typeId}`);
            entity.addTag(`owner:${nearestPlayer}`);
            entity.addTag('owned');
        }
    }
});

// Get Nearest Player
function getNearestPlayer(radius, location) {
    const nearbyPlayers = overworld.getEntities({
        type: "minecraft:player",
        maxDistance: radius,
        location: location
    });

    return nearbyPlayers.length > 0 ? nearbyPlayers[0].name : null;
}

// Get Nearest Pump
function getNearestPump(ownerTag) {
  const nearbyPumps = overworld.getEntities({
      type: "lab:pump",
      tags: [`owner:${ownerTag}`]
  });
  return nearbyPumps.map(entity => entity.location);
}


function getOwner(player) {
  //OnPlaced AutoMiner
    //Miner Recall
    if (player.hasTag("sssRecall")) {
      player.runCommandAsync(`execute as @e[type=lab:pump,r=12,tag=attemptingRecall,tag="owner:${player.name}"] at @s run tp @e[family=lab.auto_miner,tag="owner:${player.name}"] @s`);
      player.removeTag("sssRecall");
    }

    if (player.hasTag("sssPlacedAutoPump")) {
      player.runCommandAsync(`execute as @e[type=lab:pump,r=12,tag="owner:${player.name}"] at @s unless entity @e[type=loadisk:obj,r=2] run summon loadisk:obj ~ ~1 ~ ~ ~ loadisk:add.name_always_event "§6${player.name}'s Pump"`);
      player.removeTag("sssPlacedAutoPump");
  }
}